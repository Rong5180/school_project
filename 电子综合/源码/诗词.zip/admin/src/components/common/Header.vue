<template>
  <div class="header">
    <div class="header-title">
      <img class="header-img1" src="../../assets/img/main/ma.png" alt="" >
      <img class="header-img2" src="../../assets/img/main/ma.png" alt="">
      <span>诗歌天堂</span>
    </div>
    <el-button type="danger" @click="logout"> 退出</el-button>
  </div>
</template>

<script>
  export default {
    name: "Header",
    methods:{
      logout(){
        window.sessionStorage.clear();
        this.$router.push('/login')
      }
    }
  }
</script>

<style scoped>
  .header{
    height: 60px;
    background-color: #373d41;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: #fff;
    
  }
  
  .header div{
    display: flex;
    align-items: center;
    font-size: 20px;
  }
  .header div .header-img1{
    height: 50px;
    width: 50px;
    margin-right: 15px;
    z-index: 1;
  }
  .header div:hover .header-img2{
    display: block;
  }
  .header-img2{
    position: absolute;
    top: 60px;
    height: 150px;
    width: 150px;
    z-index: 9;
    display: none;
  }
</style>