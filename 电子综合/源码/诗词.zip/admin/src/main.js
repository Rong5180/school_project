import Vue from 'vue'
import App from './App.vue'
import router from './router'

//导入全局样式
import './assets/scss/normalize.css'
import './assets/scss/global.css'

//element
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
Vue.use(ElementUI);

//配置axios
import axios from 'axios'
const http = axios.create({
  baseURL:'http://s.rong5180.top/admin/api/'
  // baseURL:'http://localhost:3001/admin/api/'
})


//请求拦截器
http.interceptors.request.use(function (config) {
  if(sessionStorage.token){
    config.headers.Authorization='Bearer '+(sessionStorage.token||'')
  }
  return config
},function (error) {
  return Promise.reject(error);
})

//响应拦截器
http.interceptors.response.use(res=>{
  return res
},err=>{
  if(err.response.data.message){
    Vue.prototype.$message({
      type:'error',
      message:err.response.data.message
    })
    if(err.response.status===401){
      router.push('/login')
    }
  }
  return Promise.reject(err)
})

Vue.prototype.$http=http

Vue.mixin({
  computed:{
    uploadUrl(){
      return this.$http.defaults.baseURL+'upload'
    }
  },
  methods:{
    getAuthHeaders(){
      return{
        Authorization:`Bearer ${sessionStorage.token||''}`
      }
    }
  }
})

Vue.config.productionTip = false

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
