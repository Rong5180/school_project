import Vue from 'vue'
import VueRouter from 'vue-router'

import Login from "../views/login/Login";
import Main from "../views/Main/Main";
import PoetCreate from "../views/Main/Poet/PoetCreate";
import PoetList from "../views/Main/Poet/PoetList";
import PoetryTypeCreate from "../views/Main/PoetryTpye/PoetryTypeCreate";
import PoetryTypeList from "../views/Main/PoetryTpye/PoetryTypeList";
import TimesCreate from "../views/Main/Times/TimesCreate";
import TimesList from "../views/Main/Times/TimesList";
import PoemCreate from "../views/Main/Poem/PoemCreate";
import PoemList from "../views/Main/Poem/PoemList";
import AdCreate from "../views/Main/Ad/AdCreate";
import AdList from "../views/Main/Ad/AdList";
import AdminUserEdit from "../views/Main/Admin/AdminUserEdit";
import AdminUserList from "../views/Main/Admin/AdminUserList";
import VideoCreate from "../views/Main/Video/VideoCreate";
import VideoList from "../views/Main/Video/VideoList";

Vue.use(VueRouter)

const routes = [
  {
    path:'/',
    redirect:'/main'
  },
  {
    path: '/login',
    name: 'login',
    component: Login,
    meta:{isPublic:true}
  },
 {
    path: '/login',
    name: 'Login',
    component: Login,
  },
  {
    path: '/main',
    name: 'Main',
    component: Main,
    children:[
        //诗人路由
      {path:'/poets/list',component:PoetList},
      {path:'/poets/create',component:PoetCreate,},
      {path:'/poets/edit/:id',component:PoetCreate,props:true},
        //诗歌分类路由
      {path:'/poetry_types/list',component:PoetryTypeList},
      {path:'/poetry_types/create',component:PoetryTypeCreate},
      {path:'/poetry_types/edit/:id',component:PoetryTypeCreate,props:true},
        //时代路由
      {path:'/times/list',component:TimesList},
      {path:'/times/create',component:TimesCreate},
      {path:'/times/edit/:id',component:TimesCreate,props:true},
        //诗人路由
      {path:'/poems/list',component:PoemList},
      {path:'/poems/create',component:PoemCreate},
      {path:'/poems/edit/:id',component:PoemCreate,props:true},
        // 广告路由
      {path:'/ads/list',component:AdList},
      {path:'/ads/create',component:AdCreate},
      {path:'/ads/edit/:id',component:AdCreate,props:true},
      //管理员路由
      {path:'/admin_users/create', component:AdminUserEdit,},
      {path:'/admin_users/edit/:id', component:AdminUserEdit,props:true},
      {path:'/admin_users/list', component:AdminUserList,},

       //视频路由
      {path:'/videos/create', component:VideoCreate,},
      {path:'/videos/edit/:id', component:VideoCreate,props:true},
      {path:'/videos/list', component:VideoList,},

    ],
  },

]

const router = new VueRouter({
  routes
})

router.beforeEach((to,from,next)=>{
  if(!to.meta.isPublic&&!sessionStorage.token){
    return next('/login')
  }
  next()
})

export default router
