<template>
  <div class="about">
   <h1> {{id?'编辑':'新建'}}管理员</h1>
    <el-form label-width="120px" @submit.native.prevents="save">
     <el-form-item label="用户名">
        <el-input v-model="model.username"></el-input>
      </el-form-item>
     <el-form-item label="密码">
        <el-input  v-model="model.password"></el-input>
      </el-form-item>
     <el-form-item label="电话">
        <el-input  v-model="model.phone"></el-input>
      </el-form-item>
     <el-form-item label="描述">
        <el-input type="textarea"  v-model="model.description"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" native-type="submit" >保存</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
  export default {
    name: "AdminUserEdit",
    props:{
      id:{}
    },
    data(){
      return{
        model:{},   //表单数据对象
      }
    },
    methods:{
      //请求接口，提交分类数据
     async save(){
       let res
       if(this.id){
         res=await this.$http.put(`rest/admin_users/${this.id}`,this.model);
       }else {
         res=await this.$http.post('rest/admin_users',this.model);
       }
      //路由跳转
       await this.$router.push('/admin_users/list')
       this.$message({
         type:'success',
         message:'保存成功'
       })
      },
      //获取分类数据信息
      async fetch(){
       const res=await this.$http.get(`rest/admin_users/${this.id}`)
        this.model=res.data
      },
    },
    created() {
      this.id&&this.fetch();
    },
  }
</script>

<style scoped>

</style>