<template>
  <div class="main-body">
    <el-container >
<!--      头部-->
      <el-header>
        <Header></Header>
      </el-header>
      <el-container>
<!--        侧边栏-->
        <el-aside width="200px">
          <el-menu
                  unique-opened
                  router
                  :default-active="this.$route.path"
                  background-color="#333744" text-color="#fff"
                  active-text-color="#ffd04b">
            <el-submenu index="1">
              <template slot="title">
                <i class="el-icon-menu"></i>
                <span>分类管理</span>
              </template>
              <el-menu-item-group>
                <template slot="title">诗词分类</template>
                <el-menu-item index="/poetry_types/list">诗词分类列表</el-menu-item>
                <el-menu-item index="/poetry_types/create">增加诗词分类</el-menu-item>
              </el-menu-item-group>
              <el-menu-item-group>
                <template slot="title">诗人分类</template>
                <el-menu-item index="/poets/list">诗人列表</el-menu-item>
                <el-menu-item index="/poets/create">增加诗人</el-menu-item>
              </el-menu-item-group>
              <el-menu-item-group>
                <template slot="title">时代分类</template>
                <el-menu-item index="/times/list">时代列表</el-menu-item>
                <el-menu-item index="/times/create">增加时代</el-menu-item>
              </el-menu-item-group>
            </el-submenu>
            <el-submenu index="2">
              <template slot="title">
                <i class="el-icon-s-help"></i>
                <span>诗歌管理</span>
              </template>
              <el-menu-item-group>
                <template slot="title">诗歌分类</template>
                <el-menu-item index="/poems/list">诗歌列表</el-menu-item>
                <el-menu-item index="/poems/create">增加诗歌</el-menu-item>
              </el-menu-item-group>
            </el-submenu>
            <el-submenu index="3">
              <template slot="title">
                <i class="el-icon-s-promotion"></i>
                <span>广告管理</span>
              </template>
              <el-menu-item-group>
                <template slot="title">广告分类</template>
                <el-menu-item index="/ads/list">广告列表</el-menu-item>
                <el-menu-item index="/ads/create">增加广告</el-menu-item>
              </el-menu-item-group>
            </el-submenu>
            <el-submenu index="4">
              <template slot="title">
                <i class="el-icon-video-camera-solid"></i>
                <span>视频管理</span>
              </template>
              <el-menu-item-group>
                <template slot="title">视频分类</template>
                <el-menu-item index="/videos/list">视频列表</el-menu-item>
                <el-menu-item index="/videos/create">增加视频</el-menu-item>
              </el-menu-item-group>
            </el-submenu>
            <el-submenu index="5">
              <template slot="title">
                <i class="el-icon-user-solid"></i>
                <span>管理员管理</span>
              </template>
              <el-menu-item-group>
                <template slot="title">管理员</template>
                <el-menu-item index="/admin_users/list">管理员列表</el-menu-item>
                <el-menu-item index="/admin_users/create">增加管理员</el-menu-item>
              </el-menu-item-group>
            </el-submenu>
          </el-menu>
        </el-aside>
        <el-main>
        <router-view :key="$route.path"  />
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script>
  import Header from "../../components/common/Header";
  export default {
    name: "Main",
    components:{
      Header
    },
  }
</script>

<style scoped>
  .main-body{
    height: 100%;
  }
  .el-container{
    height: 100%;
  }
  .el-header {
    background-color: #373d41;
    color: #fff;
  }
  
  .el-aside {
    background-color: #333744;
    color: #fff;
  }
  
  .el-main {
    background-color: #eaedf1;
    color: #333;
  }

  .el-aside .el-menu{
    border-right: none;
  }
  
</style>