<template>
  <div class="poet-create">
    <h1>{{id?'编辑':'新增'}}诗歌</h1>
    <el-form label-width="120px" @submit.native.prevents="save">
      <el-form-item label="名字">
        <el-input v-model="model.name"></el-input>
      </el-form-item>
      <el-form-item label="背景图" >
        <el-upload
                class="avatar-uploader"
                :action="uploadUrl"
                :headers="getAuthHeaders()"
                :show-file-list="false"
                :on-success="res=>$set(model,'banner',res.url)">
          <img v-if="model.banner" :src="model.banner" class="avatar">
          <i v-else class="el-icon-plus avatar-uploader-icon"></i>
        </el-upload>
      </el-form-item>
      <el-form-item  label="诗人">
        <el-select clearable v-model="model.poet" clearable>
          <el-option v-for="item in poets" :key="item._id"
                     :label="item.name" :value="item._id"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item  label="时代">
        <el-select clearable v-model="model.time" clearable>
          <el-option v-for="item in times" :key="item._id"
                     :label="item.name" :value="item._id"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item  label="诗歌类型">
        <el-select multiple clearable v-model="model.poetry_types" clearable>
          <el-option v-for="item in poetry_types" :key="item._id"
                     :label="item.name" :value="item._id"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="内容">
        <vue-editor v-model="model.content"
                    useCustomImageHandler
                    @image-added="handleImageAdded">
        </vue-editor>
      </el-form-item>
     <el-form-item label="描述">
       <vue-editor v-model="model.description"
                   useCustomImageHandler
                   @image-added="handleImageAdded">
       </vue-editor>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" native-type="submit" >保存</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
  import {VueEditor} from 'vue2-editor'
  
  export default {
    props:{
      id:{},
    },
    components:{
      VueEditor,
    },
    name: "PoemCreate",
    data(){
      return{
        //诗歌数据对象
        model:{},
        times:[],  //时代数据
        poets:[],   //诗人数据
        poetry_types:[],  //诗歌类型
      }
    },
    methods:{
      //进入页面时获取要修改的数据信息
      async fetch(){
        const res=await this.$http.get(`rest/poems/${this.id}`);
        console.log(res)
        this.model=res.data;
      },
      //获取时代,诗人，诗歌数据
      async getTimes(){
        const times=await this.$http.get('rest/times');
        this.times=times.data;
        const poets=await this.$http.get('rest/poets');
        this.poets=poets.data;
        const poetry_types=await this.$http.get('rest/poetry_types');
        this.poetry_types=poetry_types.data;
      },
      //保存数据
      async save(){
        let res;
        if(this.id){
          res=await this.$http.put(`rest/poems/${this.id}`,this.model)
        }else {
          res=await this.$http.post('rest/poems',this.model)
          // console.log(res)
        }
        await this.$router.push('/poems/list')
        this.$message({
          type:'success',
          message:'保存成功'
        })
      },
      
      //图片上传
      async handleImageAdded(file, Editor, cursorLocation, resetUploader) {
        const formData = new FormData();
        formData.append("file", file);
    
        const res=await this.$http.post('upload',formData)
        Editor.insertEmbed(cursorLocation, "image", res.data.url);
        resetUploader();
      },
    },
    created() {
      this.id&&this.fetch();
      this.getTimes();
    }
  }
</script>

<style scoped>
</style>