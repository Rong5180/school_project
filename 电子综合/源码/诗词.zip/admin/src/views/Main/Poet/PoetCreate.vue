<template>
  <div class="poet-create">
    <h1>{{id?'编辑':'新增'}}诗人</h1>
    <el-form label-width="120px" @submit.native.prevents="save">
      <el-form-item label="名字">
        <el-input v-model="model.name"></el-input>
      </el-form-item>
      <el-form-item label="头像" >
        <el-upload
                class="avatar-uploader"
                :action="uploadUrl"
                :headers="getAuthHeaders()"
                :show-file-list="false"
                :on-success="res=>$set(model,'head_portrait',res.url)">
          <img v-if="model.head_portrait" :src="model.head_portrait" class="avatar">
          <i v-else class="el-icon-plus avatar-uploader-icon"></i>
        </el-upload>
      </el-form-item>
      <el-form-item label="称号">
        <el-input v-model="model.title"></el-input>
      </el-form-item>
      <el-form-item label="时代">
        <el-select v-model="model.time" clearable>
          <el-option v-for="item in times" :key="item._id"
                     :label="item.name" :value="item._id"></el-option>
        </el-select>
      </el-form-item>
     <el-form-item label="描述">
        <el-input type="textarea" v-model="model.description"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" native-type="submit" >保存</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
  export default {
    props:{
      id:{},
    },
    name: "PoetCreate",
    data(){
      return{
        //诗人数据对象
        model:{},
        times:[],  //时代数据
      }
    },
    methods:{
      //进入页面时获取要修改的数据信息
      async fetch(){
        const res=await this.$http.get(`rest/poets/${this.id}`);
        // console.log(res)
        this.model=res.data;
      },
      //获取时代数据
      async getTimes(){
        const res=await this.$http.get('rest/times');
        this.times=res.data;
      },
      //保存数据
      async save(){
        let res;
        if(this.id){
          res=await this.$http.put(`rest/poets/${this.id}`,this.model)
        }else {
          res=await this.$http.post('rest/poets',this.model)
          // console.log(res)
        }
        await this.$router.push('/poets/list')
        this.$message({
          type:'success',
          message:'保存成功'
        })
      },
    },
    created() {
      this.id&&this.fetch();
      this.getTimes();
    }
  }
</script>

<style scoped>

</style>