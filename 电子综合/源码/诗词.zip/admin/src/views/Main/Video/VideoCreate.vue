<template>
  <div class="poet-create">
    <h1> {{id?'编辑':'新增'}}视频</h1>
    <el-form label-width="120px" @submit.native.prevents="save">
      <el-form-item label="视频名称">
        <el-input v-model="model.name"></el-input>
      </el-form-item>
     <el-form-item label="视频文件">
       <el-upload
               class="avatar-uploader"
               :action="uploadUrl"
               :headers="getAuthHeaders()"
               :show-file-list="false"
               :on-success="res=>$set(model,'video',res.url)">
         <video v-if="model.video" :src="model.video" class="avatar"></video>
         <i v-else class="el-icon-plus avatar-uploader-icon"></i>
       </el-upload>
      </el-form-item>
      <el-form-item label="视频链接">
        <el-input v-model="model.url"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" native-type="submit" >保存</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
  export default {
    props:{
      id:{},
    },
    name: "AdCreate",
    data(){
      return{
        //视频数据对象
        model:{},
      }
    },
    methods:{
      //进入页面时获取要修改的数据信息
      async fetch(){
        const res=await this.$http.get(`rest/weikes/${this.id}`);
        // console.log(res)
        this.model=res.data;
      },
      //保存数据
      async save(){
        let res;
        if(this.id){
          res=await this.$http.put(`rest/weikes/${this.id}`,this.model)
        }else {
          res=await this.$http.post('rest/weikes',this.model)
          // console.log(res)
        }
        await this.$router.push('/videos/list')
        this.$message({
          type:'success',
          message:'保存成功'
        })
      },
  
      //图片上传
      async handleImageAdded(file, Editor, cursorLocation, resetUploader) {
        const formData = new FormData();
        formData.append("file", file);
    
        const res=await this.$http.post('upload',formData)
        Editor.insertEmbed(cursorLocation, "image", res.data.url);
        resetUploader();
      },
    },
    created() {
      this.id&&this.fetch();
    }
  }
</script>

<style scoped>

</style>