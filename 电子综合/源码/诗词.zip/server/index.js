const express=require('express')
const app=express()

app.set('secret','fewferfwgwg')

//json中间件
app.use(express.json())
//配置跨域
app.use(require('cors')())

//加载静态文件
app.use('/',express.static(__dirname+'/web'))
app.use('/admin',express.static(__dirname+'/admin'))

//引入数据库，后台接口
require('./plugins/db')(app)
require('./routes/admin')(app)
require('./routes/web')(app)

app.listen(3001,()=>{
  console.log('http://localhost:3001')
})