const mongoose=require('mongoose')

const schema=new mongoose.Schema({
  max:{type:String},
})

module.exports=mongoose.model('Long',schema)