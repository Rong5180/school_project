const mongoose=require('mongoose')

const schema=new mongoose.Schema({
  name:{type:String},
  poet:{type:mongoose.SchemaTypes.ObjectId,ref:'Poet'},
  time:{type:mongoose.SchemaTypes.ObjectId,ref:'Time'},
  poetry_types:[{type:mongoose.SchemaTypes.ObjectId,ref:'PoetryType'}],
  content:{type:String},
  description:{type:String},
  banner:{type:String},
})

module.exports=mongoose.model('Poem',schema)