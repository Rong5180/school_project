const mongoose=require('mongoose')

const schema=new mongoose.Schema({
  name:{type:String},
  description:{type:String},
  head_portrait:{type:String},
  time:{type:mongoose.SchemaTypes.ObjectId,ref:'Time'},
  title:{type:String},
  poetry_type:{type:mongoose.SchemaTypes.ObjectId,ref:'PoetryType'},
})

module.exports=mongoose.model('Poet',schema)