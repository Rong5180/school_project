const mongoose=require('mongoose')

const schema=new mongoose.Schema({
  name:{type:String},
  description:{type:String},
  banner:{type:String},
})

module.exports=mongoose.model('PoetryType',schema)