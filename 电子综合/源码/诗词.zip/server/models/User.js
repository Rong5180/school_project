const mongoose=require('mongoose')

const schema=new mongoose.Schema({
  username:{type:String},
  icon:{type:String},
  like_poems:[{type:mongoose.SchemaTypes.ObjectId,ref:'Poem'}],
  like_poets:[{type:mongoose.SchemaTypes.ObjectId,ref:'Poet'}],
  description:{type:String},
  phone:{type:String},
  password:{
    type:String,
    select:false,
    set(val){
      return require('bcrypt').hashSync(val,10)
    }},
},{
  timestamps: true
})

module.exports=mongoose.model('User',schema)