module.exports=app=>{
  
  //导入express
  const express=require('express')
  const assert=require('http-assert')
  const jwt=require('jsonwebtoken')
  const AdminUser=require('../../models/AdminUser')
  const router=express.Router({
    mergeParams:true,//用于获取url参数
  })
  
  
  //新增接口
  router.post('/',async(req,res)=>{
  const model=await req.Model.create(req.body)
    res.send(model)
  })
  
  //获取列表接口
  router.get('/',async(req,res)=>{
    //判断是否要查询关联数据
    const queryOptions={}
    if(req.Model.modelName==='Poet'){
      const Time=require('../../models/Time')
      queryOptions.populate='time'
    }
   if(req.Model.modelName==='Poem'){
     const poet=require('../../models/Poet')
     const Time=require('../../models/Time')
     const PoetryType=require('../../models/PoetryType')
      queryOptions.populate='time poet poetry_types'
    }
    const items=await req.Model.find().setOptions(queryOptions);
    res.send(items);
  })
  
  //获取详情接口
  router.get('/:id',async(req,res)=>{
    const model=await req.Model.findById(req.params.id);
    res.send(model);
  })
  
  //修改接口
  router.put('/:id',async(req,res)=>{
    const model=await req.Model.findByIdAndUpdate(req.params.id,req.body)
    res.send(model)
  })
  
  //删除接口
  router.delete('/:id',async(req,res)=>{
    await req.Model.findByIdAndDelete(req.params.id,req.body)
    res.send({
      success:true,
    })
  })
  
  //文件上传
  const multer=require('multer')
  const MAO = require('multer-aliyun-oss')
  const upload=multer({
    // dest:__dirname+'/../../uploads'
    storage: MAO({
      config: {
        region: 'oss-cn-hangzhou',
        accessKeyId: 'LTAI4GKQxYGb2gb4rn28Mcj8',
        accessKeySecret: '7cAJiwMPFCwCoE8G1FCwYghmwn2Ktr',
        bucket: 'poetry-rong'
      }
    })
  })
  // const upload=multer({dest:'../../uploads'})
  app.post('/admin/api/upload',upload.single('file'),async(req,res)=>{
    const file=req.file
    // file.url=`http://moba.rong5180.top:3000/uploads/${file.filename}`
    res.send(file)
  })
  
  //登录校验中间件封装
  const authMiddleware=require('../../middleware/auth')
  //资源模型中间件
  const resourceMiddleware=require('../../middleware/resource')
  //挂载路由
  app.use('/admin/api/rest/:resource',authMiddleware(),resourceMiddleware(),router)
  
  //登录请求
  app.post('/admin/api/login' ,async (req,res)=>{
    const {username,password}=req.body;
    // console.log(req.body)
    //1.根据用户名找用户
    const user=await AdminUser.findOne({username}).select('+password')
    assert(user,422,'用户不存在1')
    
    // 2.校验密码
    const isValid= require('bcrypt').compareSync(password,user.password)
    assert(isValid,422,'密码错误')
    
    //3.返回token
    const token=jwt.sign({id:user._id,},app.get('secret'))
    res.send({token})
  })
  
  //错误处理
  app.use(async(err,req,res,next)=>{
    res.status(err.statusCode||500).send({
      message:err.message
    })
  })
  
}