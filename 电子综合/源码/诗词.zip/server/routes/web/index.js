module.exports=app=>{
  
  //导入express
  const mongoose = require('mongoose')
  const express=require('express')
  const assert=require('http-assert')
  const jwt=require('jsonwebtoken')
  const User=require('../../models/User')
  const router=express.Router({
    mergeParams:true,//用于获取url参数
  })
  const router2=express.Router({
    mergeParams:true,//用于获取url参数
  })
  
  
  //新增接口
  router.post('/',async(req,res)=>{
    if(req.Model.modelName==='User'){
      const {username,password}=req.body;
      const user=await User.findOne({username}).select('+password')
      assert(!user,422,'用户名已存在')
      const model=await req.Model.create(req.body)
      res.send(model)
    }else{
      const model=await req.Model.create(req.body)
      res.send(model)
    }
    
  })
  
  //获取列表接口
  router.get('/',async(req,res)=>{
    //判断是否要查询关联数据
    const queryOptions={}
    if(req.Model.modelName==='Poet'){
      const Time=require('../../models/Time')
      queryOptions.populate='time'
    }
    if(req.Model.modelName==='Poem'){
      const poet=require('../../models/Poet')
      const Time=require('../../models/Time')
      const PoetryType=require('../../models/PoetryType')
      queryOptions.populate='time poet poetry_types'
    }
    const items=await req.Model.find().setOptions(queryOptions);
    res.send(items);
  })
  
  //获取详情接口
  router.get('/:id',async(req,res)=>{
    //判断是否要查询关联数据
    const queryOptions={}
    if(req.Model.modelName==='Poet'){
      const Time=require('../../models/Time')
      const poem=require('../../models/Poem')
      queryOptions.populate='time'
    }
    if(req.Model.modelName==='Poem'){
      const poet=require('../../models/Poet')
      const Time=require('../../models/Time')
      const PoetryType=require('../../models/PoetryType')
      queryOptions.populate='time poet poetry_types'
    }
    if(req.Model.modelName==='User'){
      const Time=require('../../models/Time')
      const poet=require('../../models/Poet')
      const poem=require('../../models/Poem')
      const PoetryType=require('../../models/PoetryType')
      queryOptions.populate='like_poems like_poets '
    }
    const model=await req.Model.findById(req.params.id).setOptions(queryOptions).lean();
    //相关诗歌
    if(req.Model.modelName==='Poem'){
      model.related = await req.Model.find().setOptions(queryOptions).where({
        poet: { $in: model.poet }
      }).limit(2)
    }
    if(req.Model.modelName==='Poet'){
      const Poem = mongoose.model('Poem')
      const total=await Poem.find().where({
        poet:{$in:model._id}
      }).count()
      model.total=total;
      model.related = await req.Model.aggregate( [ { $sample: { size: 2 } } ] )
    }
    // console.log(model)
    res.send(model);
  })
  

  
  //修改接口
  router.put('/:id',async(req,res)=>{
    const model=await req.Model.findByIdAndUpdate(req.params.id,req.body)
    res.send(model)
  })
  
  //删除接口
  router.delete('/:id',async(req,res)=>{
    await req.Model.findByIdAndDelete(req.params.id,req.body)
    res.send({
      success:true,
    })
  })
  

  
  //文件上传
  const multer=require('multer')
  const MAO = require('multer-aliyun-oss')
  const upload=multer({
    // dest:__dirname+'/../../uploads'
    storage: MAO({
      config: {
        region: 'oss-cn-hangzhou',
        accessKeyId: 'LTAI4GKQxYGb2gb4rn28Mcj8',
        accessKeySecret: '7cAJiwMPFCwCoE8G1FCwYghmwn2Ktr',
        bucket: 'poetry-rong'
      }
    })
  })
  // const upload=multer({dest:'../../uploads'})
  app.post('/web/api/upload',upload.single('file'),async(req,res)=>{
    const file=req.file
    // file.url=`http://moba.rong5180.top:3000/uploads/${file.filename}`
    res.send(file)
  })
  

  

  //资源模型中间件
  const resourceMiddleware=require('../../middleware/resource')
  //挂载路由
  app.use('/web/api/rest/:resource',resourceMiddleware(),router)
  
  /**
   * 特殊接口处理
   */
  //获取诗歌分类详情接口
  router2.get('/poet-types/:id',async(req,res)=>{
    const queryOptions={}
    const poem=require('../../models/Poem')
    const Poem = mongoose.model('Poem')
    const poet=require('../../models/Poet')
    const Time=require('../../models/Time')
    const PoetryType=require('../../models/PoetryType')
    queryOptions.populate='time poet poetry_types'
    
    
    let model=await Poem.find().setOptions(queryOptions).where({
      poetry_types:{$in:req.params.id}
    }).lean()
  
    const title=await PoetryType.findById(req.params.id);
    model.title=title
    // console.log(model)
    res.send({
      model,
      title
    })
  })
  //根据时代获取诗歌数据
  router2.get('/times',async(req,res)=>{
    const queryOptions={}
    const time=require('../../models/Time')
    const poet=require('../../models/Poet')
    const Time = mongoose.model('Time')
    const Poet = mongoose.model('Poet')
    const model=await Time.find().lean();
   model.map(async item=>{
     item.poet=await Poet.find().where({
       time:{$in:item._id}
     })
   })
    model.unshift({
      name:'全部',
      poet:await Poet.find(),
    })
    res.send(model)
  })
  //根据诗人获取诗歌数据
  router2.get('/poems/:id',async(req,res)=>{
    const queryOptions={}
    const time=require('../../models/Time')
    const poet=require('../../models/Poet')
    const Poem = mongoose.model('Poem')
    let model=await Poem.find().setOptions(queryOptions).where({
      poet:{$in:req.params.id}
    }).lean()

    res.send(model)
  })
  //获取网站注册总人数
  router2.get('/users',async(req,res)=>{
    const user=require('../../models/User')
    const User = mongoose.model('User')
    const total=await User.find().count();
    res.send(total)
  })
  //飞花令接口
  router2.get('/fei/:query',async (req,res)=>{
    const query = req.params.query;
    const reg = new RegExp( query );
    const Poem=require('../../models/Poem')
    const model=await Poem.find({'content':reg}).populate('poet');
    res.send(model)
  })
  
  app.use('/web/api/rest1',router2)
  
  //登录请求
  app.post('/web/api/login' ,async (req,res)=>{
    const {username,password}=req.body;
    // console.log(req.body)
    //1.根据用户名找用户
    const user=await User.findOne({username}).select('+password')
    assert(user,422,'用户不存在')
    
    // 2.校验密码
    const isValid= require('bcrypt').compareSync(password,user.password)
    assert(isValid,422,'密码错误')
    
    //3.返回user
    res.send(user)
  })
  
  //错误处理
  app.use(async(err,req,res,next)=>{
    res.status(err.statusCode||500).send({
      message:err.message
    })
  })
  
}