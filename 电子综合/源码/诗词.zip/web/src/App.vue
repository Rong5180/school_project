<template>
  <div id="app">
    <router-view :key="$route.path" class="app-body" />
    <van-tabbar route>
      <van-tabbar-item replace to="/home" icon="home-o">首页</van-tabbar-item>
      <van-tabbar-item replace to="/poem" icon="search">诗歌</van-tabbar-item>
      <van-tabbar-item replace to="/poet" icon="friends-o">诗人</van-tabbar-item>
      <van-tabbar-item replace to="/interest" icon="fire-o">趣味</van-tabbar-item>
      <van-tabbar-item replace to="/my" icon="setting-o">我的</van-tabbar-item>
    </van-tabbar>
  </div>
</template>

<script>
  export default {
    name: "App",
    data() {
      return {
      
      };
    },
  }
  
</script>

<style scoped>
  body{
    height: 100%;
    background: #ccc;
    min-width: max-content;
    min-width: -moz-max-content;
  }
#app{
  height: 100%;
}
  .app-body{
    margin-bottom: 4rem;
  }
</style>
