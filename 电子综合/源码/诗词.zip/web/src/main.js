import Vue from 'vue'
import App from './App.vue'
import router from './router'

//导入全局样式
import './assets/css/normalize.css'
import './assets/css/global.css'
//vantui
import '../src/vantui/vant'

//日期格式化
import moment from 'moment'
Vue.prototype.$moment = moment



//配置axios
import axios from 'axios'
const http = axios.create({
  // baseURL: process.env.VUE_APP_API_URL || '/web/api'
  // baseURL: 'http://localhost:3001/web/api'
  baseURL:'http://s.rong5180.top/web/api'
  
})

Vue.prototype.$http=http;

Vue.config.productionTip = false

//响应拦截器
http.interceptors.response.use(res=>{
  return res
},err=>{
  if(err.response.data.message){
    Vue.prototype.$toast({
      type:'error',
      message:err.response.data.message
    })
    if(err.response.status===401){
      router.push('/login')
    }
  }
  return Promise.reject(err)
})

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
