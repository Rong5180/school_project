import Vue from 'vue'
import VueRouter from 'vue-router'

import Home from "../views/Home/Home";
import My from "../views/My/My";
import Poem from "../views/Poem/Poem";
import Poet from "../views/Poet/Poet";
import HomePoem from "../views/Home/HomePoem";
import HomeAd from "../views/Home/HomeAd";
import HomePoet from "../views/Home/HomePoet";
import PoemDetails from "../views/Poem/PoemDetails";
import MyLogin from "../views/My/MyLogin";
import MyPoem from "../views/My/MyPoem";
import MyPoet from "../views/My/MyPoet";
import Interest from "../views/Interest/Interest";
import Acrostic from "../views/Interest/Acrostic";
import Xhy from "../views/Interest/Xhy";
import Long from "../views/Interest/Long";
import Weike from "../views/Interest/Weike";
import Fei from "../views/Interest/Fei";

Vue.use(VueRouter)

const routes = [
  {
    path:'/',
    redirect:'/home'
  },
    //登录
  {
    path:'/login',
    component:MyLogin,
  },
    //首页
  {
    path:'/home',
    component:Home
  },
    //我的
  {
    path:'/my',
    component:My
  },
    //诗人
  {
    path:'/poem',
    component:Poem
  },
    //诗歌
  {
    path:'/poet',
    component:Poet
  },
   //趣味
  {
    path:'/interest',
    component:Interest,
    redirect:'/interest/long',
    children:[
        //藏头诗
      {path:'/interest/acrostic',component:Acrostic,meta:{active:1}},
        //歇后语
      {path:'/interest/xhy',component:Xhy,meta:{active:2}},
        //成语接龙
      {path:'/interest/long',component:Long,meta:{active:0}},
        //微课
      {path:'/interest/weike',component:Weike,meta:{active:3}},
         //飞花令
      {path:'/interest/fei',component:Fei,meta:{active:4}},
    ]
  },
    //首页诗歌详情
  {
    path:'/home-poem/:id',
    component:HomePoem,
    props:true
  },
    //首页广告详情
  {
    path:'/home-ad/:id',
    component:HomeAd,
    props:true
  },
  //诗人详情页
  {
    path:'/home-poet/:id',
    component:HomePoet,
    props:true
  },
  //诗歌分类详情页
  {
    path:'/poem-details/:id',
    component:PoemDetails,
    props:true
  },
 //我的收藏诗歌详情页
  {
    path:'/my-poem/:id',
    component:MyPoem,
    props:true
  },
 //我的收藏诗人详情页
  {
    path:'/my-poet/:id',
    component:MyPoet,
    props:true
  },
  

]

const router = new VueRouter({
  routes
})

export default router
