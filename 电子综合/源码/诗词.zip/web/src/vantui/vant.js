import Vue from 'vue';
import Vant from 'vant';
import 'vant/lib/index.css';
Vue.use(Vant);

import { Button,Tabbar, TabbarItem,NavBar,Swipe, SwipeItem,Collapse,CollapseItem,Col,Row,Tab,Tabs,
         Form,Toast,Uploader,SwipeCell,DropdownMenu,DropdownItem} from 'vant';

Vue.use(Tabbar);
Vue.use(TabbarItem);
Vue.use(Button);
Vue.use(NavBar);
Vue.use(Swipe);
Vue.use(SwipeItem);
Vue.use(Collapse);
Vue.use(CollapseItem);
Vue.use(Col);
Vue.use(Row);
Vue.use(Tab);
Vue.use(Tabs);
Vue.use(Form);
Vue.use(Toast);
Vue.use(Uploader);
Vue.use(SwipeCell);
Vue.use(DropdownMenu);
Vue.use(DropdownItem);