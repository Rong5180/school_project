<template>
  <div>
<!--    头部导航栏-->
    <nav-bar class="nav-bar">
      <div slot="center">诗词中心</div>
      <div class="nav-search" slot="right"> <van-icon name="search" /></div>
    </nav-bar>
<!--    轮播-->
    <van-swipe   class="my-swipe" :autoplay="3000" indicator-color="black">
      <van-swipe-item v-for="item in ads" >
        <router-link :to="`/home-ad/${item._id}`"> <img :src="item.image" alt="" ></router-link>
      </van-swipe-item>
    </van-swipe>
<!--    诗歌展示-->
    <van-collapse v-model="activeNames" accordion>
      <van-collapse-item class="poem-card" v-for="(item,index) in poems" :name="index">
        <template #title>
          <div class="poem">
            <router-link  :to="`/home-poem/${item._id}`" class="poem-name">{{item.name}}</router-link>
            <div class="poem-poet"> <router-link class="poem-poet-name" :to="`/home-poet/${item.poet._id}`">{{item.poet.name}}</router-link>   {{item.time.name}}</div>
          </div>
        </template>
        <div v-html="item.content" class="poem-content" > </div>
      </van-collapse-item>
    </van-collapse>
    
  </div>
</template>

<script>
  import NavBar from "../../components/navbar/NavBar";
  export default {
    name: "Home",
    components:{
      NavBar,
    },
    data(){
      return{
        ads:[],   //广告数据
        activeNames: ['1'],
        poems:[],     //诗歌数据信息
      }
    },
    methods:{
      async getData(){
        const resAd=await this.$http.get('/rest/ads');
        this.ads=resAd.data;
        const resPoem=await this.$http.get('/rest/poems');
        // console.log(resPoem.data)
        this.poems=resPoem.data;
      }
    },
    created() {
      this.getData()
    },
  }
</script>

<style scoped>
.nav-bar{
  background: #373d41;
  color: #fff;
  font-weight: bolder;
}

.nav-search{
  font-size: 1.5rem;
  line-height: 50px;
}

.my-swipe{
  height: 200px;
  width: 100%;
}
  .my-swipe img{
    height: 200px;
    width: 100%;
  }
  
.poem-card{
    background: #791a15;
    margin-top: .3em;
    box-shadow: .1rem .1rem .1rem #888888
  }
 .poem{
   text-align: center;
 }
  .poem .poem-name{
    color: #000;
    font-weight: bolder;
  }
  
  .poem .poem-poet{
    font-size: .8rem;
    font-weight: lighter;
  }

.poem-poet-name{
  color: #791a15;
}
  
  .poem-content{
    color: #373d41;
    text-align: center;
    line-height: 0.5rem;
  }
</style>