<template>
  <div v-if="ad">
    <img class="ad-img" :src="ad.image" alt="">
    <div class="ad-name">{{ad.name}}</div>
    <div class="ad-content" v-html="ad.body"></div>
  </div>
</template>

<script>
  export default {
    props:{
      id:{}
    },
    name: "HomeAd",
    data(){
      return{
        ad:null,     //广告数据对象
      }
    },
    methods:{
      async getData(){
        console.log('123')
        const res=await this.$http.get(`rest/ads/${this.id}`);
        // console.log(res.data)
        
        this.ad=res.data;
      },
    },
    created() {
      this.getData();
    }
  }
</script>

<style scoped>
.ad-img{
  width: 100%;
  height: 200px;
}
  .ad-name{
    text-align: center;
    font-size: 1.5rem;
    font-weight: bolder;
    margin-top: 1rem;
  }
  .ad-content {
    max-width: 100%;
    overflow: hidden;
  }
</style>