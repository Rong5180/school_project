<template>
  <div>
    <div class="poem" v-if="poem">
      <img class="poem-banner" :src="poem.banner" alt="">
      <div class="poem-name">{{poem.name}}</div>
      <div class="poem-poet">
        <router-link class="poem-poet-name" :to="`/home-poet/${poem.poet._id}`">{{poem.poet.name}}</router-link>
        {{poem.time.name}}
      </div>
      <div class="poem-content" v-html="poem.content"></div>
      <div class="poem-type">标签：<span v-for="item in poem.poetry_types">{{item.name}} </span></div>
      <div style="text-align: center;margin-top: 1rem"><van-button style="width: 5rem;height: 2rem;" :disabled="isTrue" @click="likePoem"  type="primary">{{isTrue?'已收藏':'收藏'}}</van-button></div>
      <div class="poem-description" v-html="poem.description"></div>
      <div class="poem-recommend">
        <div>推荐诗歌：</div>
        <div>
          <router-link
                  class="poem-related"
                  tag="div"
                  :to="`/home-poem/${item._id}`"
                  v-for="item in poem.related"
                  :key="item._id"
          ><span class="span-left">{{item.name}}</span> <span>{{item.poet.name}}</span> </router-link>
        </div>
      </div>
    </div>
    
   
  </div>
</template>

<script>
  export default {
    name: "HomePoem",
    props:{
      id:{}
    },
    data(){
      return{
        poem:null,    //诗歌详情数据
        user:null,   //用户数据详情
        isTrue:false,  //用户是否收藏
      }
    },
    methods:{
      async getData(){
      const resPoem=await this.$http.get(`rest/poems/${this.id}`);
        this.poem=resPoem.data
        const id=window.sessionStorage.getItem('id')
        if(id){
          const resUser=await this.$http.get(`rest/users/${id}`)
          this.user=resUser.data;
          this.isTrue=this.user.like_poems.some(item=>item._id===this.poem._id)
          // console.log(this.user)
        }
        
      },
      //收藏诗歌函数
      async likePoem(){
        const id=window.sessionStorage.getItem('id')
        if(!id){
          await this.$router.push('/login')
          return
        }
        this.user.like_poems.push(this.poem._id);
        await this.$http.put(`rest/users/${id}`,this.user);
        this.$toast.success('收藏成功！')
        this.isTrue=true;
       }
    },
    created() {
      this.getData()
    }
  }
</script>

<style scoped>
  .poem-banner{
    height: 10rem;
    width: 100%;
    overflow: hidden;
  }
.poem{
  text-align: center;
  height: 100%;
}
  .poem .poem-name{
    font-size: 1.3rem;
    margin-bottom: .5rem;
    font-weight: bolder;
  }
  .poem .poem-content{
    line-height: .5rem;
  }
  .poem .poem-type{
    font-size: .8rem;
   color: #4b67af;
  }
  .poem .poem-description{
    text-align: left;
  }
  
  .poem-recommend{
    text-align: left;
  }
  .poem-related{
    color: darkslategray;
    margin-top: .5rem;
    display: flex;
    justify-content: space-between;
  }
  .poem-related .span-left{
    color: #791a15;
  }
</style>