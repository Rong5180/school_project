<template>
  <div class="home-poet" v-if="poet">
    <img class="poet-img" :src="poet.head_portrait" alt="">
    <div class="fs-b fw">[{{poet.time.name}}] {{poet.name}} </div>
    <div class="mt-1 cr" v-if="poet.title">称号：{{poet.title}}</div>
    <div class="mt-1" >诗词总数：<span style="color: darkslateblue">{{poet.total}}</span> 首</div>
    <div style="text-align: center;margin-top: 1rem"><van-button style="width: 5rem;height: 2rem;" :disabled="isTrue" @click="likePoet"  type="primary">{{isTrue?'已收藏':'收藏'}}</van-button></div>
  
    <div class="mt-1 tr">描述：{{poet.description}} </div>
<!--    诗词展示-->
    <van-collapse v-model="activeNames" accordion>
      <van-collapse-item class="poem-card" v-for="(item,index) in poem" :name="index">
        <template #title>
          <div class="poem">
            <router-link  :to="`/home-poem/${item._id}`" class="poem-name">{{item.name}}</router-link>
             </div>
        </template>
        <div v-html="item.content" class="poem-content" > </div>
      </van-collapse-item>
    </van-collapse>
    <div class="mt-2 tr"><span style="color: darkolivegreen">推荐诗人：</span><br>
                <router-link :to="`/home-poet/${item._id}`" class="mb-1 cr2 poet-related" v-for="item in poet.related"
                     v-if="item.name!==poet.name">
                  <div>{{item.name}}</div>
                  <img class="related-img" :src="item.head_portrait" alt="">
                </router-link>
    </div>
  </div>
</template>

<script>
  export default {
    name: "HomePoet",
    props:{
      id:{}
    },
    data(){
      return{
        activeNames:'',
        poet:null,            //诗人数据列表
        poem:null,            //诗歌数据列表
        isTrue:false          //用户是否收藏
      }
    },
    methods:{
      //获取数据
    async getData(){
      const resPoet=await this.$http.get(`rest/poets/${this.id}`);
      this.poet=resPoet.data;
      const resPoem=await this.$http.get(`rest1/poems/${this.id}`);
      this.poem=resPoem.data;
      const id=window.sessionStorage.getItem('id')
      if(id){
        const resUser=await this.$http.get(`rest/users/${id}`)
        this.user=resUser.data;
        this.isTrue=this.user.like_poets.some(item=>item._id===this.poet._id)
        // console.log(this.user)
      }
    },
      //收藏诗人
      async likePoet(){
        const id=window.sessionStorage.getItem('id')
        if(!id){
          await this.$router.push('/login')
          return
        }
        this.user.like_poets.push(this.poet._id);
        await this.$http.put(`rest/users/${id}`,this.user);
        this.$toast.success('收藏成功！')
        this.isTrue=true;
      },

    },
    created() {
    this.getData();
    },
  }
</script>

<style scoped>
  .mt-1{
    margin-top: .3rem;
  }
  .mb-1{
    margin-bottom: .3rem;
  }
  .mt-2{
    margin-top: .6rem;
  }
  .fs-b{
    font-size: 1.2rem;
  }
  .cr{
    color: #791a15;
  }
  .cr2{
    color: darkslategray;
  }
  .tr{
    text-align: left;
  }
  .fw{
    font-weight: bolder;
  }
.home-poet{
  height: 100%;
  text-align: center;
}

.home-poet .poet-img{
  margin-top: 1rem;
  height: 6rem;
  width: 6rem;
  border-radius: 50%;
}
  .poet-related{
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: .1rem .1rem .1rem #888888
  }
  .poet-related .related-img{
    height: 2rem;
    width: 2rem;
    border-radius: 50%;
  }

  .poem-card{
    background: #791a15;
    margin: .5em 0;
    box-shadow: .1rem .1rem .1rem #888888
  }
  .poem{
    text-align: center;
  }
  .poem .poem-name{
    color: #000;
    font-weight: bolder;
  }
  

  .poem-content{
    color: #373d41;
    text-align: center;
    line-height: 0.5rem;
  }
</style>