<template>
  <div>
    <div style="margin-top: 1rem;display: flex;align-items: center">
      <input v-model="cang" style="width: 60%;margin: 0 .5rem;height: 26px;padding: 0;" type="text">
      <select class="mr-5 h" v-model="select">
        <option value ="4">五言</option>
        <option value ="6">七言</option>
      </select>
      <van-button class="h" style="width: 4rem" type="info" size="mini" @click="choose">确定</van-button>
      
    </div>
    <div class="shi" v-if="content">
      <div v-for="item in content">{{item}}</div>
    </div>
    
  </div>
</template>

<script>
  export default {
    name: "Acrostic",
    data(){
      return{
        select:'4',
        cang:'',  //藏头诗头
        content:null,
        zi:'的一了是我不在人们有来他这上着个地到大里说就去子得' +
            '也和那要下看天时过出小么起你都把好还多没为又可家学' +
            '只以主会样年想生同老中十从自面前头道它后然走很像见' +
            '两用她国动进成回什边作对开而己些现山民候经发工向事' +
            '命给长水几义三声于高手知理眼志点心战二问但身方实' +
            '吃做叫当住听革打呢真全才四已所敌之最光产情路分总条' +
            '白话东席次亲如被花口放儿常气五第使写军吧文运再果' +
            '怎定许快明行因别飞外树物活部门无往船望新带队先力' +
            '完却站代员机更九您每风级跟笑啊孩万少直意夜比阶' +
            '连车重便斗马哪化太指变社似士者干石满日决百原拿群' +
            '究各六本思解立河村八难早论吗根共让相研今其书坐' +
            '接应关信觉步反处记将千找争领或师结块跑谁草越字加脚紧爱等习阵怕月青半火法题建赶位唱海七女任件感' +
            '准张团屋离色脸片科倒睛利世刚且由送切星导晚表够整认响雪流未场该并底深刻平伟忙提确近亮轻讲农古黑' +
            '告界拉名呀土清阳照办史改历转画造嘴此治北必服' +
            '雨穿内识验传业菜爬睡兴形量咱观苦体众通冲合破' +
            '友度术饭公旁房极南枪读沙岁线野坚空收算至政城' +
            '劳落钱特围弟胜教热展包歌类渐强数乡呼性音答哥' +
            '际旧神座章帮啦受系令跳非何牛取入岸敢掉忽种装' +
            '顶急林停息句区衣般报叶压慢叔背细'
      }
    },
    methods:{
      getRandomArrayElements(arr, count) {
        let shuffled = arr.slice(0), i = arr.length, min = i - count, temp, index;
        while (i-- > min) {
          index = Math.floor((i + 1) * Math.random());
          temp = shuffled[index];
          shuffled[index] = shuffled[i];
          shuffled[i] = temp;
        }
        return shuffled.slice(min);
      },
      choose(){
       let items=this.zi.split('');
        this.content=this.cang.split('')
        for (let i = 0; i <this.content.length ; i++) {
          let item =this.getRandomArrayElements(items, this.select).join('')
          this.content[i]=this.content[i]+item;
        }
      }
    }
  }
</script>

<style scoped>
  .h{
    height: 2rem;
  }
.mr-5{
  margin-right: .5rem;
}
  .shi{
    margin-top: 1rem;
    line-height: 1.5rem;
    text-align: center;
    font-weight: bolder;
    color: #373d41;
  }
</style>