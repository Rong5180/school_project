<template>
  <div>
      <div style="margin-top: 1rem;display: flex;align-items: center;justify-content: center">
        <input v-model="keyWord" type="text" style="margin: 0 .5rem;padding: 0;height: 26px;padding-left: .5rem;">
        <van-button style="height: 30px;width: 5rem" type="primary" size="small" @click="search" >查询</van-button>
      </div>
    
    <div>
      <van-collapse v-if="poem" v-model="activeNames" accordion>
        <van-collapse-item class="poem-card" v-for="(item,index) in poem" :name="index">
          <template #title>
            <div class="poem">
              <router-link  :to="`/home-poem/${item._id}`" class="poem-name">{{item.name}}</router-link>
            </div>
          </template>
          <div v-html="item.content" class="poem-content" ></div>
        </van-collapse-item>
      </van-collapse>
    </div>
  </div>
</template>

<script>
  export default {
    name: "Fei",
    data(){
      return{
        keyWord:'',
        activeNames: '',
        poem:null,
      }
    },
    methods:{
      async search(){
      const res=await this.$http.get(`rest1/fei/${this.keyWord}`);
      this.poem=res.data;
        const reg = new RegExp( this.keyWord,"g" );
        this.poem.map(item=>{
          item.content=item.content.replace(reg,"<span style='color: red;'>$&</span>");
        })
      }
    },
  }
</script>

<style scoped>
  
  .poem-card{
    background: #791a15;
    margin-top: .3em;
    box-shadow: .1rem .1rem .1rem #888888
  }
  .poem{
    text-align: center;
  }
  .poem .poem-name{
    color: #791a15;
    font-weight: bolder;
  }
  .poem-content{
    color: #373d41;
    text-align: center;
    line-height: 0.5rem;
  }
</style>