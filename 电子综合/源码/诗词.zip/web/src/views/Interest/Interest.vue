<template>
  <div>
    <van-tabs v-model="active" ref="tabs" sticky>
      <van-tab title="成语接龙" to="/interest/long"></van-tab>
      <van-tab title="藏头诗"  to="/interest/acrostic"></van-tab>
      <van-tab title="歇后语"  to="/interest/xhy"></van-tab>
      <van-tab title="微课"    to="/interest/weike"></van-tab>
      <van-tab title="飞花令"    to="/interest/fei"></van-tab>
    </van-tabs>
    <router-view :key="$route.path" />
  </div>
</template>

<script>
  export default {
    name: "Interest",
    data(){
      return{
        active: this.$route.meta.active,
      }
    },
    methods:{
    
    },
  }
</script>

<style scoped>

</style>