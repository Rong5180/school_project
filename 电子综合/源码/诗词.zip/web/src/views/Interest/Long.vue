<template>
  <div>
    <div style="margin-top: 1rem;display: flex;align-items: center;justify-content: center">
      <input v-model="keyWord" type="text" style="margin: 0 .5rem;padding: 0;height: 26px;padding-left: .5rem;">
      <van-button style="height: 30px;width: 5rem" type="primary" size="small" @click="jieLong" :disabled="over">接龙</van-button>
    </div>
    <div v-if="arr.length" style="text-align: center">
      <div class="long" v-for="(item,index) in arr" :class="index%2===0?'red':''">{{item}}</div>
       <div style="margin-top: 1rem;">当前分数:<span style="color: #dd6161">{{grade}}</span></div>
       <div></div>
    </div>
    <div style="text-align: center">
      <div style="margin-top: 1rem;" v-if="long.length">全网接龙最高分:<span style="color: red">{{long[long.length-1].max}}</span></div>
      <van-button style="height: 30px;width: 5rem;margin-top: 1rem" type="info" size="small" @click="reset" v-if="over">重来</van-button>
    </div>
    </div>
</template>

<script>
  import axios from 'axios'
  export default {
    name: "Long",
    data(){
      return{
        keyWord:'',
        arr:[],
        grade:0,
        over:false,
        long:{},
      }
    },
    methods:{
      async jieLong(){
        // console.log(this.keyWord)
        const res=await axios.get('http://api.tianapi.com/txapi/chengyujielong/index',{
          params:{
            key:'9f6e31967de88967dd1073e1adf86bad',
            userid:'98105401289c18d858c169578ecf0125',
            word:this.keyWord
          }
        })
        this.arr.push(this.keyWord);
        this.arr.push(res.data.newslist[0].chengyu)
        this.grade=res.data.newslist[0].grade;
        //重启游戏
        if(res.data.newslist[0].result>1)
          this.over=true;
        //系统失败重启
        if(!res.data.newslist[0].chengyu)
          await this.$toast({
            message: '找不到相应成语，您赢了',
            icon: 'like-o',
          })
        //玩家失败重启
       if(res.data.newslist[0].tip.search('貌似')!==-1)
          await this.$toast({
            message: '貌似这不是一个成语呢,请重新开始游戏',
            icon: 'like-o',
          })
        //舞文巧诋
        this.keyWord=''
      },
      reset(){
      this.arr=[];
      this.over=false;
      },
    },
    created() {
    }
  }
</script>

<style scoped>
.red{
  color: darkslategrey;
}
  .long{
    height: 1.5rem;
    border: 1px solid #000;
    text-align: center;
    line-height: 1.5rem;
    margin-top: .5rem;
    box-shadow: .1rem .1rem .1rem #888888
  
  }
  .tip{
    margin-top: 1rem;
    color: darkslategrey;
  }
</style>