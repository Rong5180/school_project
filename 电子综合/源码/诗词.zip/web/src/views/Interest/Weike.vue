<template>
  <div>
    <div class="weike" v-for="(item,index) in weike" :key="item._id">
      <video class="weike-video" :src="item.video"  @play="handlePlay(index)" controls="controls"></video>
      <div>{{item.name}}</div>
    </div>
  </div>
</template>

<script>
  export default {
    name: "Weike",
    data(){
      return{
      weike:null,
      }
    },
    methods:{
      async getData(){
        const res=await this.$http.get('/rest/weikes');
        this.weike=res.data;
        console.log(res.data)
      },
      handlePlay (index) {
        const videoElement = this.videoElement
        if (videoElement && videoElement.length > 0) {
          for (let i = 0; i < videoElement.length; i++) {
            if (i === index) {
              this.videoElement[i].play()
            } else {
              this.videoElement[i].pause()
            }
          }
        }
      },
    },
    created() {
      this.getData();
    },
    mounted () {
      this.videoElement = document.getElementsByTagName('video') // 获取页面上所有的video对象
    },
    
  }
</script>

<style scoped>
  .weike{
    text-align: center;
    font-weight: bolder;
    color: #2c3e50;
    margin-top: 1rem;
    box-shadow: .1rem .1rem .1rem #888888
  }
.weike-video{
  height: 15rem;
  width: 100%;
}
</style>