<template>
  <div>
    <van-collapse v-model="activeName" accordion>
      <van-collapse-item class="con" v-for="(item,index) in xhy" :title="item.quest" :name="index"><span style="color: darkslategrey">{{item.result}}</span></van-collapse-item>
    </van-collapse>
    <div style="text-align: center;margin-top: 1rem">
      <van-button style="width: 4rem;" @click="getData" type="danger" size="small">刷新</van-button>
    </div>
    
  </div>
</template>

<script>
  import axios from 'axios'
  export default {
    name: "Xhy",
    data(){
      return{
        xhy:null,
        activeName:'',
      }
    },
    methods:{
      async getData(){
        const res=await axios.get('http://api.tianapi.com/txapi/xiehou/index',{
          params:{
            key:'9f6e31967de88967dd1073e1adf86bad',
            num:10
          }
        })
        this.xhy=res.data.newslist;
      }
    },
    created() {
      this.getData();
    }
  }
</script>

<style scoped>
.con{
  margin-top: .5rem;
  box-shadow: .1rem .1rem .1rem #888888
}
</style>