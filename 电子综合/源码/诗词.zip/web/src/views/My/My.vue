<template>
  <div class="my">
    <div class="my-title" >我的</div>
    <div v-if="user">
      <div class="my-head">
        <van-uploader :after-read="imgSend"  v-model="files"  :max-count="1" />
      </div>
      
      <div class="user-card">用户名：<span style="color: darkslategray">{{user.username}}</span></div>
      <div class="user-card">
        用户注册时间：<span style="color: saddlebrown">{{$moment(user.createdAt).format('YYYY-MM-DD')}}</span>
      </div>
      <router-link :to="`/my-poem/${user._id}`" tag="div" class="user-card">喜欢的诗歌</router-link>
      <router-link :to="`/my-poet/${user._id}`" tag="div" class="user-card">喜欢的诗人</router-link>
      <div class="user-card">网站注册总人数：<span style="color: red">{{total}}</span></div>
      <div style="text-align: center;margin-top: 1rem"><van-button style="width: 8rem" @click="layout" type="danger">退出</van-button></div>
    </div>
    <router-link v-else to="/login" tag="div" class="login-btn" >
      <van-button type="primary">登录/注册</van-button>
    </router-link>
  </div>
</template>

<script>
  export default {
    name: "My",
    data(){
      return {
        user:null,   //用户数据信息
        total:0,         //网站注册总人数
        files:[
          {url:''}
        ],
      }
    },
    methods: {
      //获取用户数据
    async getData(){
    const id=sessionStorage.getItem('id')||null;
      if(id){
        const res=await this.$http.get(`rest/users/${id}`);
        this.user=res.data
        this.files[0].url=this.user.icon
      }
      const total=await this.$http.get('rest1/users');
      this.total=total.data;
    },
      //图片上传函数
      async imgSend(file){
        // console.log(file.file)
        const formData = new FormData();
        formData.append("file", file.file);
        const res=await this.$http.post('upload',formData)
        this.user.icon=res.data.url
        // console.log(this.user)
        const res2=await this.$http.put(`rest/users/${this.user._id}`,this.user)
        // console.log(res2.data)
      },
      //退出
      layout(){
        window.sessionStorage.clear();
        this.$router.push('/login')
      }
    },
    created() {
      this.getData();
    }
  }
</script>

<style scoped>
  .my{
    height: 100%;
  }
  .my-title{
    padding-top: 1rem;
    font-weight: bolder;
    font-size: 1.5rem;
    text-align: center;
  }
 .login-btn{
   padding-top: 10rem ;
   text-align: center;
 }
  .my-head{
    margin-top: 1rem;
    text-align: center;
  }
  .user-card{
    height: 2rem;
    line-height: 2rem;
    border: 1px solid #000;
    margin-top: .5rem;
    box-shadow: .1rem .1rem .1rem #000
  }
</style>