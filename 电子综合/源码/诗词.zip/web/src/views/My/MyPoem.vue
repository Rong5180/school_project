<template>
  <div v-if="user">
    <div class="my-title">收藏诗歌</div>
    <van-collapse v-model="activeNames" accordion>
      <van-collapse-item class="poem-card" v-for="(item,index) in user.like_poems" :name="index">
        <template #title>
          <div class="poem">
            <router-link  :to="`/home-poem/${item._id}`" class="poem-name">{{item.name}}</router-link>
             </div>
        </template>
        <div v-html="item.content" class="poem-content" ></div>
        <div style="text-align: center; ">
          <van-button @click="cancleLike(item._id)" style="width: 7rem;height: 2.5rem;" type="info">取消收藏</van-button>
        </div>
      </van-collapse-item>
    </van-collapse>
  </div>
</template>

<script>
  export default {
    props:{
      id:{}
    },
    name: "MyPoem",
    data(){
      return{
        user:null,  //用户数据信息
        activeNames: '',
        poems:[],     //诗歌数据信息
      }
    },
    methods:{
      //获取数据
      async getData(){
        const res=await this.$http.get(`rest/users/${this.id}`);
        this.user=res.data;
        console.log(this.user)
      },
      //取消收藏数据
     async cancleLike(id){
       
       for(let index = this.user.like_poems.length - 1; index >= 0; index--) {
         if(this.user.like_poems[index] && this.user.like_poems[index]._id === id) {
           this.user.like_poems.splice(index, 1)
         }
       }
       await this.$http.put(`rest/users/${this.user._id}`,this.user);
       await this.$toast.success('删除成功！')
       this.activeNames='';
     }
    },
    created() {
      this.getData()
    }
  }
</script>

<style scoped>
  .my-title{
    padding-top: 1rem;
    font-weight: bolder;
    font-size: 1.5rem;
    text-align: center;
    margin-bottom: .6rem;
  }
  .poem-card{
    background: #791a15;
    margin-top: .3em;
    box-shadow: .1rem .1rem .1rem #888888
  }
  .poem{
    text-align: center;
  }
  .poem .poem-name{
    color: #791a15;
    font-weight: bolder;
  }
  .poem-content{
    color: #373d41;
    text-align: center;
    line-height: 0.5rem;
  }
</style>