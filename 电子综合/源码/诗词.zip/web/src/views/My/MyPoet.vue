<template>
  <div v-if="user">
    <div class="my-title">收藏诗人</div>
    <van-swipe-cell v-for="item in user.like_poets" :key="item._id">
      <router-link  :to="`/home-poet/${item._id}`">
      <van-cell border :title="item.name"   value="左滑删除">
      </van-cell>
      </router-link>
        <template #right>
          <van-button @click="cancleLike(item._id)" square type="danger" text="删除" />
        </template>
    </van-swipe-cell>
  </div>
</template>

<script>
  export default {
    props:{
      id:{}
    },
    name: "MyPoem",
    data(){
      return{
        user:null,  //用户数据信息
      }
    },
    methods:{
      //获取数据
      async getData(){
        const res=await this.$http.get(`rest/users/${this.id}`);
        this.user=res.data;
        // console.log(this.user)
      },
      //取消收藏数据
      async cancleLike(id){
        
        for(let index = this.user.like_poets.length - 1; index >= 0; index--) {
          if(this.user.like_poets[index] && this.user.like_poets[index]._id === id) {
            this.user.like_poets.splice(index, 1)
          }
        }
        await this.$http.put(`rest/users/${this.user._id}`,this.user);
        await this.$toast.success('删除成功！')
      }
    },
    created() {
      this.getData()
    }
  }
</script>

<style scoped>
  .my-title{
    padding-top: 1rem;
    font-weight: bolder;
    font-size: 1.5rem;
    text-align: center;
    margin-bottom: .6rem;
  }
.van-swipe-cell{
  margin-top: .2rem;
  box-shadow: .1rem .1rem .1rem #000
}
</style>