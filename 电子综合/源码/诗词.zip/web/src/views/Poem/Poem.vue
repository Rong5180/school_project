<template>
  <div class="poem">
    <div class="poem-title">诗词分类</div>
    <van-row class="poem-row" gutter="15" align="bottom">
      <van-col class="poem-row" span="12" v-for="item in poem">
        <router-link
                tag="div"
                :to="`/poem-details/${item._id}`"
        >
          <img class="poem-banner" :src="item.banner" alt="">{{item.name}}
        </router-link>
        
      </van-col>
    </van-row>
  </div>
  
</template>

<script>
  export default {
    name: "Poem",
    data(){
      return{
        poem:[],          //诗歌数据
      }
    },
    methods:{
      async getData(){
        const resPoem=await this.$http.get('/rest/poetry_types');
        this.poem=resPoem.data;
        console.log(this.poem)
      }
    },
    created() {
      this.getData()
    }
  }
</script>

<style scoped>
  body{
    background: white;
    margin-bottom: 7rem;
    min-width: max-content;
    min-width: -moz-max-content;
  }
  
.poem-title{
  padding-top: 1rem;
  text-align: center;
  font-size: 1.5rem;
  font-weight: bolder;
  margin-bottom: 1rem;
}
  .poem-row{
    text-align: center;
    font-size: 1.2rem;
    margin-bottom: .5rem;
    box-shadow: .1rem .1rem .1rem #000;
    overflow-y:auto;
  }
.poem-row .poem-banner{
  height: 5rem;
  width: 100%;
}
</style>