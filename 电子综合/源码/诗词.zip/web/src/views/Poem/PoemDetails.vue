<template>
  <div v-if="poem">
    <img class="poem-banner" :src="poem.title.banner" alt="">
    <div class="poem-title">{{poem.title.name}}</div>
    <div style="margin-bottom: 1rem;font-size: .8rem;font-weight: lighter;">{{poem.title.description}}</div>
<!--    诗歌展示-->
    <van-collapse v-model="activeNames" accordion>
      <van-collapse-item class="poem-card" v-for="(item,index) in poem.model" :name="index">
        <template #title>
          <div class="poem">
            <router-link  :to="`/home-poem/${item._id}`" class="poem-name">{{item.name}}</router-link>
            <div class="poem-poet"> <router-link class="poem-poet-name" :to="`/home-poet/${item.poet._id}`">{{item.poet.name}}</router-link>   {{item.time.name}}</div>
          </div>
        </template>
        <div v-html="item.content" class="poem-content" > </div>
      </van-collapse-item>
    </van-collapse>
  </div>
</template>

<script>
  export default {
    props:{
      id:{}
    },
    name: "PoemDetails",
    data(){
      return{
        activeNames: ['1'],
        poem:null,  //诗歌数据
      }
    },
    methods:{
      async getData(){
       const res=await this.$http.get(`/rest1/poet-types/${this.id}`);
        this.poem=res.data;
        // console.log(this.poem)
      },
    },
    created() {
      this.getData()
    }
  }
</script>

<style scoped>
  .poem-banner{
    height: 10rem;
    width: 100%;
  }
  .poem-title{
    padding-top: .2rem;
    font-size: 1.2rem;
    font-weight: bolder;
    text-align: center;
  }
  .poem-card{
    background: #791a15;
    margin-top: .3em;
    box-shadow: .1rem .1rem .1rem #888888
  }
  .poem{
    text-align: center;
  }
  .poem .poem-name{
    color: #000;
    font-weight: bolder;
  }
  
  .poem .poem-poet{
    font-size: .8rem;
    font-weight: lighter;
  }
  
  .poem-poet-name{
    color: #333333;
  }
  
  .poem-content{
    color: #373d41;
    text-align: center;
    line-height: 0.5rem;
  }
</style>