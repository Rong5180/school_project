<template>
  <div class="poet">
    <div class="poet-title">作者</div>
    <van-tabs
            class="poet-tab"
            title-active-color="red"
            title-inactive-color="darkslategray"
            border
            swipeable
            sticky>
      <van-tab v-for="item in poet" :title="item.name" :key="item._id">
        <van-row class="poem-row" gutter="15" align="bottom">
          <van-col class="poem-row"  span="12" v-for="item in item.poet">
            <router-link
                    tag="div"
                    :to="`/home-poet/${item._id}`"
            >
              <img class="poem-banner" :src="item.head_portrait" alt="">
              <div class="poet-name">{{item.name}}</div>
              <div class="poet-details">{{item.description}}</div>
            </router-link>
    
          </van-col>
        </van-row>
      </van-tab>
    </van-tabs>

  </div>
</template>

<script>
  export default {
    name: "Poet",
    data(){
      return{
      poet:[],  //诗人数据对象
      }
    },
    methods:{
      async getData(){
        const res=await this.$http.get('/rest1/times');
        this.poet=res.data;
        // console.log(this.poet)
      },
    },
    created() {
      this.getData();
    }
  }
</script>

<style scoped>
  body{
    background: darkslategrey;
    height: 100%;
    min-width: max-content;
    min-width: -moz-max-content;
  }
  
  .poet-title{
    padding-top: 1rem;
    text-align: center;
    font-size: 1.5rem;
    font-weight: bolder;
    margin-bottom: .5rem;
  }
/*诗人展示*/
  .poem-row{
    text-align: center;
    font-size: 1.2rem;
    margin-bottom: .5rem;
    box-shadow: .1rem .1rem .1rem #000;
    overflow-y:auto;
  }
  .poem-row .poem-banner{
    margin-top:.5rem;
    height: 2rem;
    width: 2rem;
    border-radius: 50%;
  }
  .poet-name{
    color: #4b67af;
  }
  .poet-details{
    padding: 0 .5rem;
    margin-bottom: .5rem;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    margin-top: .2rem;
    font-size: .8rem;
    color: #333333;
  }
</style>